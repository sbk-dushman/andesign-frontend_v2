# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<AppFooter>` | `<app-footer>` (components/AppFooter.vue)
- `<AppIcon>` | `<app-icon>` (components/AppIcon.vue)
- `<AppMap>` | `<app-map>` (components/AppMap.vue)
- `<AppMasthead>` | `<app-masthead>` (components/AppMasthead.vue)
- `<AppNav>` | `<app-nav>` (components/AppNav.vue)
- `<AppSearch>` | `<app-search>` (components/AppSearch.vue)
- `<CaseViewer>` | `<case-viewer>` (components/CaseViewer.vue)
- `<ModalComponent>` | `<modal-component>` (components/ModalComponent.vue)
- `<Nav3DTuor>` | `<nav3-d-tuor>` (components/Nav3DTuor.vue)
- `<NavContacts>` | `<nav-contacts>` (components/NavContacts.vue)
- `<NavPresentations>` | `<nav-presentations>` (components/NavPresentations.vue)
- `<NavVideo>` | `<nav-video>` (components/NavVideo.vue)
- `<OrderForm>` | `<order-form>` (components/OrderForm.vue)
- `<PCaseSlider>` | `<p-case-slider>` (components/PCaseSlider.vue)
- `<Portfolio>` | `<portfolio>` (components/Portfolio.vue)
- `<PortfolioSlider>` | `<portfolio-slider>` (components/PortfolioSlider.vue)
- `<SearchToggle>` | `<search-toggle>` (components/SearchToggle.vue)
- `<TourModal>` | `<tour-modal>` (components/TourModal.vue)
- `<VideoModal>` | `<video-modal>` (components/VideoModal.vue)
- `<VideoPlayer>` | `<video-player>` (components/VideoPlayer.vue)
