export const AppFooter = () => import('../..\\components\\AppFooter.vue' /* webpackChunkName: "components/app-footer" */).then(c => wrapFunctional(c.default || c))
export const AppIcon = () => import('../..\\components\\AppIcon.vue' /* webpackChunkName: "components/app-icon" */).then(c => wrapFunctional(c.default || c))
export const AppMap = () => import('../..\\components\\AppMap.vue' /* webpackChunkName: "components/app-map" */).then(c => wrapFunctional(c.default || c))
export const AppMasthead = () => import('../..\\components\\AppMasthead.vue' /* webpackChunkName: "components/app-masthead" */).then(c => wrapFunctional(c.default || c))
export const AppNav = () => import('../..\\components\\AppNav.vue' /* webpackChunkName: "components/app-nav" */).then(c => wrapFunctional(c.default || c))
export const AppSearch = () => import('../..\\components\\AppSearch.vue' /* webpackChunkName: "components/app-search" */).then(c => wrapFunctional(c.default || c))
export const CaseViewer = () => import('../..\\components\\CaseViewer.vue' /* webpackChunkName: "components/case-viewer" */).then(c => wrapFunctional(c.default || c))
export const ModalComponent = () => import('../..\\components\\ModalComponent.vue' /* webpackChunkName: "components/modal-component" */).then(c => wrapFunctional(c.default || c))
export const Nav3DTuor = () => import('../..\\components\\Nav3DTuor.vue' /* webpackChunkName: "components/nav3-d-tuor" */).then(c => wrapFunctional(c.default || c))
export const NavContacts = () => import('../..\\components\\NavContacts.vue' /* webpackChunkName: "components/nav-contacts" */).then(c => wrapFunctional(c.default || c))
export const NavPresentations = () => import('../..\\components\\NavPresentations.vue' /* webpackChunkName: "components/nav-presentations" */).then(c => wrapFunctional(c.default || c))
export const NavVideo = () => import('../..\\components\\NavVideo.vue' /* webpackChunkName: "components/nav-video" */).then(c => wrapFunctional(c.default || c))
export const OrderForm = () => import('../..\\components\\OrderForm.vue' /* webpackChunkName: "components/order-form" */).then(c => wrapFunctional(c.default || c))
export const PCaseSlider = () => import('../..\\components\\PCaseSlider.vue' /* webpackChunkName: "components/p-case-slider" */).then(c => wrapFunctional(c.default || c))
export const Portfolio = () => import('../..\\components\\Portfolio.vue' /* webpackChunkName: "components/portfolio" */).then(c => wrapFunctional(c.default || c))
export const PortfolioSlider = () => import('../..\\components\\PortfolioSlider.vue' /* webpackChunkName: "components/portfolio-slider" */).then(c => wrapFunctional(c.default || c))
export const SearchToggle = () => import('../..\\components\\SearchToggle.vue' /* webpackChunkName: "components/search-toggle" */).then(c => wrapFunctional(c.default || c))
export const TourModal = () => import('../..\\components\\TourModal.vue' /* webpackChunkName: "components/tour-modal" */).then(c => wrapFunctional(c.default || c))
export const VideoModal = () => import('../..\\components\\VideoModal.vue' /* webpackChunkName: "components/video-modal" */).then(c => wrapFunctional(c.default || c))
export const VideoPlayer = () => import('../..\\components\\VideoPlayer.vue' /* webpackChunkName: "components/video-player" */).then(c => wrapFunctional(c.default || c))

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
